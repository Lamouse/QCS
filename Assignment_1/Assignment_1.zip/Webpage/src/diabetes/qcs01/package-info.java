@javax.xml.bind.annotation.XmlSchema(namespace = "http://server/")
package diabetes.qcs01;
